
package com.nt.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nt.Employee.Employee;
import com.nt.Employee.EmployeeDao;

/**
 * Servlet implementation class emp
 */
@SuppressWarnings("serial")
@WebServlet("/emp")
public class emp extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			HttpSession session=request.getSession(true);

			String s1=request.getParameter("search");
			System.out.println(s1);
			if(s1==null || s1.isEmpty()){
				session.setAttribute("list",new EmployeeDao().Display_all_Emps());
				session.setAttribute("ids", new EmployeeDao().Display_All_ids());
				/*
				 * RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
				 * rd.forward(request, response);
				 */
				response.sendRedirect("index.jsp");
			} else {
					 session.setAttribute("list",new EmployeeDao().Display_Emp_By_id(Integer.parseInt(s1)));
					 session.setAttribute("ids", new EmployeeDao().Display_All_ids());
					 
					 /*  RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
				  rd.forward(request, response);*/
					 
					 response.sendRedirect("index.jsp");			
					 
				 }
		 		}catch(SQLException e)	{
		e.printStackTrace();
	}catch(Exception e)
	{
		e.printStackTrace();
	}
}

}
