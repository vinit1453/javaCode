package com.nt.Employee;

import java.util.Date;

public class Employee {
private int eid;
private String ename;
private Date doj;
private Float exp;
private String desg;




public Employee(int eid, String ename, Date doj,Float exp, String desg) {
	super();
	this.eid = eid;
	this.ename = ename;
	this.doj = doj;
	this.desg = desg;
}
public Employee() {
	
}
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}
public Float getExp() {
	return exp;
}
public void setExp(Float exp) {
	this.exp = exp;
}

public String getDesg() {
	return desg;
}
public void setDesg(String desg) {
	this.desg = desg;
}

}
