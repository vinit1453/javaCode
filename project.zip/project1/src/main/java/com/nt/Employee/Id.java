package com.nt.Employee;

public class Id {
private int Id;

public int getId() {
	return Id;
}

public Id() {
	super();
}

public Id(int id) {
	super();
	Id = id;
}

public void setId(int id) {
	Id = id;
}
}
