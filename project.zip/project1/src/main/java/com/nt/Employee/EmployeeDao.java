package com.nt.Employee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDao {
	private String jdbcUrl = "jdbc:mysql://localhost:3306/emp";
	private String userName = "root";
	private String passWord = "Vinit@2000";

	private static final String select_All_emps = "select * from emp";
	private static final String select_emps_By_id = "select * from emp where id=?";
	private static final String update_Emp_set = "update emp set id=?,name=?,doj=?,exp=?,job=?";
	private static final String select_All_Ids="select id from emp";


	protected Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection(jdbcUrl, userName, passWord);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;

	}

	// update query
	public boolean update_Emp_set(Employee emp) throws SQLException {
		boolean updatedRow;
		try (Connection con = getConnection(); PreparedStatement pst = con.prepareCall(update_Emp_set);) {
			pst.setInt(1, emp.getEid());
			pst.setString(2, emp.getEname());
			pst.setDate(3, (java.sql.Date) emp.getDoj());
			pst.setFloat(4,emp.getExp());
			pst.setString(5, emp.getDesg());
			updatedRow = pst.executeUpdate() > 0;
		}
		return updatedRow;
	}

	// select Emp by id
	public List<Employee> Display_Emp_By_id(int id) throws SQLException {
		List<Employee> list =new ArrayList<Employee>();
		try (Connection con = getConnection(); PreparedStatement pst = con.prepareCall(select_emps_By_id);) {
			pst.setInt(1, id);

			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Employee emp=new Employee();

				emp.setEid(rs.getInt("id"));
				emp.setEname( rs.getString("name"));
				emp.setDoj(rs.getDate("doj"));
				emp.setExp(rs.getFloat("exp"));
				emp.setDesg(rs.getString("job"));
				list.add(emp);
			
			}
		}
		return list;
	}

	// slect all
	public List<Employee> Display_all_Emps() throws SQLException {
		 List<Employee> list=new ArrayList<Employee>();
		try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(select_All_emps);) {
			System.out.println(pst);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Employee emp=new Employee();

				emp.setEid(rs.getInt("id"));
				emp.setEname( rs.getString("name"));
				emp.setDoj(rs.getDate("doj"));
				emp.setExp(rs.getFloat("exp"));
				emp.setDesg(rs.getString("job"));
				list.add(emp);
				
			}
		}
		return list;
	}
	
	//List of Ids
	public List<Id> Display_All_ids() throws SQLException{
		List<Id> list1=new ArrayList<Id>();
		try (Connection con = getConnection(); PreparedStatement pst = con.prepareStatement(select_All_Ids);) {
			System.out.println(pst);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {
				Id id=new Id();
				id.setId(rs.getInt(1));
				list1.add(id);
			}
		}
		return list1;
	}
	
	
}